# ProjetoOO

Colaboradores:
221007582 | Camila Costa de S. Careli
221008688 | Pedro Paulo Santos Almeida

Mini Cenário: Estudo pra concurso
     Um aluno deseja estudar para concurso. Para isso, é necessário adicionar o seu nome, um email e uma senha, ou seja, um login. Logo, ele poderá buscar por 1 ou mais editais específicos. Após isso, ele pode buscar por questões de provas anteriores de uma determinada matéria.
     Um administrador banca examinadora, loga também colocando seu nome, email e senha para acessar com o seu idAdmin. Após logar, o administrador da banca adicionará a banca no qual ele está representando, inserindo o nome fantasia de tal banca. Terminando a etapa de identificação, a banca poderá criar e deletar editais de sua banca e inserir provas anteriores, a fim de que os alunos tenham acesso.

Com o intuito de promover uma facilidade pros estudos para concursos, é desejado aplicar:
> CRUD de edital: nome do concurso, regras da prova, taxa de incrição, data do concurso, data aberta;
> CRUD de questões: tem questões de multiplaescolha e questões do tipo texto;
> Listagem de questões;
> Busca por questões de uma determinada matéria e
> Listagem de editais com a inscrição aberta na data atual.
